"""A neutral, readable form of the league's state, and the digest that proves two states are the same.

Why it exists. A league file (persist.py) holds pickles, which are valid only for the code that wrote them. To carry a league across a code
change, the state is written here in a form that names every type explicitly and can be checked without running anything, read by the
new code, and compared with the old by value. This module is deliberately self-contained (standard library and numpy only, no import of
the rest of `dfl` except by class name when decoding) so that a tool can load it from a file path next to *older* code and export that
code's league.

What it preserves, exactly: every int and float (floats by `repr`, which round-trips), every exact `Fraction` (the ledger's money), strings,
bytes, tuples, lists, dicts **in insertion order**, sets, `random.Random` generator state, numpy arrays and scalars, dates, and any object
of a `dfl` class with its attributes. Shared references and cycles are kept (two names for one list stay two names for one list).
Derived caches listed in `IGNORE` are written as None; `EXCLUDED` lists, with reasons, every attribute the state digest leaves out.

What it does not do: it does not translate between versions of the code. If a class gained, lost or renamed an attribute, `RENAMES` and
`ADAPTERS` are the places to say how; `RENAMES` is empty and `ADAPTERS` holds only the ledger's trading window and the league-owned parity settings (below). Export alone is not a migration: see persist.upgrade, which exports under
the code that wrote the league, imports under the new code, checks the state by value and records the change.
"""
import base64
import datetime
import gzip
import hashlib
import importlib
import json
import random
import sys
import types
from collections import OrderedDict, defaultdict, deque
from itertools import chain
from fractions import Fraction

import numpy as np

DOC_FORMAT = "dfl-state"
DOC_VERSION = 2                 # 2: digests use algorithm 2 (below); version 1 documents carry algorithm-1 digests and are refused
DIGEST_VERSION = 2              # the state digest algorithm; recorded in every league file and state document
IGNORE = ("_units",)            # derived caches: written as None in a state document, and left out of digests
EXCLUDED = {                    # attribute names the state digest leaves out, and why; everything else reachable from the universe is in it
    "_units": "squad cache of unit ratings, recomputed on demand from the cards; written as None",
    "_memo": "contract cache of release charges, recomputed on demand from the contract's own fields",
    "dir": "where this machine keeps the data tables; the tables themselves are covered by the code fingerprint",
    "archive_buffer": "the per-event hand-off to the permanent archive: filled during an event, drained into the journal's commit, "
                      "and covered there by the batch's record count and digest (a journal column) and the archive's own chain",
    "archive": "the resolver's alias of that same buffer",
}
DIGEST_IGNORE = tuple(EXCLUDED)
RENAMES = {}        # {"old.module.Class": "new.module.Class"} for classes that moved between versions
ADAPTERS = {}       # {"new.module.Class": callable(obj, attrs_dict)} to fill attributes a newer class expects


def _ledger_trading_window(obj, attrs):
    """Ledger state written before the ledger kept the trading window (it was then derived, wrongly, from phase and week alone, which
    left January and the post-season open) has no `trading` entry. The ledger alone cannot tell whether 1 February has passed, so the
    window is marked unknown (None, which the ledger treats as closed) and `_universe_trading_window` settles it from the events the
    league has fired. A bare ledger with no league around it stays closed until `open_trading` is called."""
    if "trading" not in attrs:
        attrs["trading"] = None


def _universe_trading_window(obj, attrs):
    """Settle an unknown window from the calendar: open exactly when this year's `trading_open` has fired and `trade_close` has not."""
    L = getattr(attrs.get("world"), "L", None)
    if L is not None and getattr(L, "trading", False) is None:
        keys = {k for (y, _, k) in attrs.get("fired", ()) if y == L.year}
        L.trading = "trading_open" in keys and "trade_close" not in keys and L.phase != "post"


def _ledger_owned_config(obj, attrs):
    """State written before the cap belonged to the league (it was then the module constant `rules.CAP`, rewritten process-wide by
    the parity profile) has no `cap`. It is marked unknown (None) and `_universe_owned_config` settles it from the league's profile."""
    if "cap" not in attrs:
        attrs["cap"] = None


def _season_run_owned_config(obj, attrs):
    """Likewise the returner rule of a season run (it was the module constant `draft.RETURNER_BLOCK`)."""
    if "returner_block" not in attrs:
        attrs["returner_block"] = None


def _universe_owned_config(obj, attrs):
    """Settle the league-owned parity settings that an older state did not carry, from the profile name it does carry."""
    from . import parity
    name = attrs.get("profile", "tight")
    s = parity.settings(name)
    if "returner_block" not in attrs:
        attrs["returner_block"] = s["returner_block"]
    L = getattr(attrs.get("world"), "L", None)
    if L is not None and getattr(L, "cap", 0) is None:
        L.cap = s["cap"]
    run = attrs.get("run")
    if run is not None and getattr(run, "returner_block", 0) is None:
        run.returner_block = s["returner_block"]


def _universe_adapter(obj, attrs):
    _universe_trading_window(obj, attrs)
    _universe_owned_config(obj, attrs)


def _ledger_adapter(obj, attrs):
    _ledger_trading_window(obj, attrs)
    _ledger_owned_config(obj, attrs)


ADAPTERS["dfl.ledger.ledger.Ledger"] = _ledger_adapter
ADAPTERS["dfl.year.Universe"] = _universe_adapter
ADAPTERS["dfl.league.SeasonRun"] = _season_run_owned_config


class NeutralError(Exception):
    pass


# ---------------------------------------------------------------------------------------------------------------- digest
def deep_digest(obj, ignore=DIGEST_IGNORE):
    """The state digest (algorithm `DIGEST_VERSION`): a SHA-256 over an entire object graph that depends only on the values in it, not on
    memory addresses, hash randomisation or which process built it. It is the journal's per-event check as well as the exhaustive one, so
    it covers every attribute of every object reached from `obj` except the names in `EXCLUDED` (each with its reason), and:

      * every random generator contributes its complete state (Mersenne words, position and the cached Gaussian);
      * dicts and lists count in order (code iterates them, so their order is state); sets count as sets (their iteration order is not
        part of the state: it depends on hashing, and code must not rely on it);
      * a shared object is digested once, and every object stays alive until the digest is done: the memo is keyed by address, and a
        temporary (the tuple `Random.getstate()` returns) freed early would let a later object reuse its address and inherit its digest.

    Strings are built bottom-up and hashed once per object, which is what makes a full digest cheap enough to take after every event."""
    seen = {}
    alive = []
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 20000))

    def plain(seq):
        return set(map(type, seq)) <= _PLAIN

    def enc(o):
        t = type(o)
        if t in _PLAIN:
            return repr(o)
        if t is bytes:
            return "b" + repr(o)
        i = id(o)
        r = seen.get(i)
        if r is not None:
            return r
        seen[i] = "~"                                 # in progress: a cycle meets this marker
        alive.append(o)
        if t is list or t is tuple:
            r = repr(o) if plain(o) else ("[" if t is list else "(") + ",".join(map(enc, o)) + "]"
        elif t is dict:
            ks, vs = set(map(type, o)), set(map(type, o.values()))
            if ks <= _PLAIN and vs <= _PLAIN or (ks == {tuple} and vs <= _PLAIN and plain(list(chain.from_iterable(o)))):
                r = repr(o)
            else:
                r = "{" + ",".join([enc(k) + ":" + enc(v) for k, v in o.items()]) + "}"
        elif t is Fraction:
            r = "F%d/%d" % (o.numerator, o.denominator)
        elif t is set or t is frozenset:
            r = t.__name__ + "<" + ",".join(sorted(map(enc, o))) + ">"
        elif isinstance(o, random.Random):
            r = "R" + hashlib.blake2b(repr(o.getstate()).encode(), digest_size=20).hexdigest()
        elif isinstance(o, np.ndarray):
            r = "A" + str(o.dtype) + repr(o.shape) + hashlib.blake2b(o.tobytes(), digest_size=20).hexdigest()
        elif isinstance(o, np.generic):
            r = "g" + repr(o)
        elif isinstance(o, dict):
            r = "D" + t.__qualname__ + "{" + ",".join([enc(k) + ":" + enc(v) for k, v in o.items()]) + "}"
        elif isinstance(o, (set, frozenset)):
            r = "S" + t.__qualname__ + "<" + ",".join(sorted(map(enc, o))) + ">"
        elif isinstance(o, (list, tuple, deque)):
            r = "Q" + t.__qualname__ + "[" + ",".join(map(enc, o)) + "]"
        elif isinstance(o, (int, float, str, bytes)):
            r = "s" + t.__qualname__ + repr(o)
        elif isinstance(o, (type, types.FunctionType, types.MethodType, types.BuiltinFunctionType)):
            r = "c" + getattr(o, "__module__", "") + "." + getattr(o, "__qualname__", repr(o))
        elif hasattr(o, "__dict__") or hasattr(t, "__slots__"):
            prim, rest = [], []
            for k, v in _attrs(o).items():
                if k not in ignore:
                    (prim if type(v) in _PLAIN else rest).append((k, v))
            prim.sort(key=_first)
            rest.sort(key=_first)
            body = repr(prim) + "|" + ",".join([k + "=" + enc(v) for k, v in rest])
            r = "H" + hashlib.blake2b((t.__module__ + "." + t.__qualname__ + "{" + body + "}").encode(), digest_size=20).hexdigest()
        else:
            r = f"o{t.__module__}.{t.__qualname__}:{o!r}"
        seen[i] = r
        return r

    return hashlib.sha256(enc(obj).encode()).hexdigest()


_PLAIN = frozenset({type(None), bool, int, float, str})
_first = lambda kv: kv[0]       # noqa: E731


def _attrs(o):
    state = dict(getattr(o, "__dict__", {}))
    for klass in type(o).__mro__:
        for sl in getattr(klass, "__slots__", ()) or ():
            if hasattr(o, sl):
                state[sl] = getattr(o, sl)
    return state


# ---------------------------------------------------------------------------------------------------------------- diagnostics
def _children(o):
    """(label, child) pairs of a container or league object, for walking a state by path."""
    if isinstance(o, dict):
        return [(f"[{k!r}]", v) for k, v in o.items()]
    if isinstance(o, (list, tuple, deque)):
        return [(f"[{i}]", v) for i, v in enumerate(o)]
    if isinstance(o, (set, frozenset)):
        return []
    if hasattr(o, "__dict__") or hasattr(type(o), "__slots__"):
        return [(f".{k}", v) for k, v in _attrs(o).items()]
    return []


def rng_states(obj):
    """{path: short digest of the generator's full state} for every random.Random reached from `obj`, found in the same order every
    time (dict order is the order the state was built in). Part of what a mismatch report compares."""
    out, seen = {}, set()

    def walk(o, path):
        if id(o) in seen or isinstance(o, (type(None), bool, int, float, str, bytes)):
            return
        seen.add(id(o))
        if isinstance(o, random.Random):
            out[path] = hashlib.sha256(repr(o.getstate()).encode()).hexdigest()[:16]
            return
        for label, child in _children(o):
            walk(child, path + label)
    walk(obj, "u")
    return out


def digest_parts(obj, depth=2):
    """{path: deep_digest} for each attribute of `obj` and of its attributes (to `depth` levels), so a mismatch can be narrowed to the part
    of the league that differs. Each part is digested on its own."""
    out = {}

    def walk(o, path, d):
        if d == 0 or isinstance(o, (type(None), bool, int, float, str, bytes)):
            return
        for label, child in _children(o):
            if label[1:] in IGNORE or label[1:] in DIGEST_IGNORE:
                continue
            out[path + label] = deep_digest(child)[:16]
            walk(child, path + label, d - 1)
    walk(obj, "u", depth)
    return out


def state_diff(expected, actual, limit=25):
    """Where two encoded states (the output of `encode`) differ: [(path, expected, actual)] with short renderings, at most `limit`, plus
    the count of differences found. Paths follow the encoding (`$o`/`s` attribute pairs, `$l` lists, `$d` dict pairs)."""
    found = []

    def short(x):
        text = json.dumps(x, sort_keys=True, default=str) if not isinstance(x, str) else x
        return text if len(text) <= 160 else text[:157] + "..."

    def walk(a, b, path):
        if len(found) >= limit * 20:
            return
        if type(a) is not type(b):
            found.append((path, short(a), short(b)))
        elif isinstance(a, dict):
            if "$o" in a and "s" in a and "s" in b and a.get("$o") == b.get("$o"):
                da, db = dict((k, v) for k, v in a["s"]), dict((k, v) for k, v in b["s"])
                for k in sorted(set(da) | set(db)):
                    if k not in da or k not in db:
                        found.append((f"{path}.{k}", short(da.get(k, "<missing>")), short(db.get(k, "<missing>"))))
                    else:
                        walk(da[k], db[k], f"{path}.{k}")
                return
            for k in sorted(set(a) | set(b)):
                if k not in a or k not in b:
                    found.append((f"{path}.{k}", short(a.get(k, "<missing>")), short(b.get(k, "<missing>"))))
                else:
                    walk(a[k], b[k], f"{path}.{k}")
        elif isinstance(a, list):
            if len(a) != len(b):
                found.append((f"{path}#len", len(a), len(b)))
            for i, (x, y) in enumerate(zip(a, b)):
                walk(x, y, f"{path}[{i}]")
        elif a != b:
            found.append((path, short(a), short(b)))
    walk(expected, actual, "u")
    return {"count": len(found), "first": found[:limit]}


# ---------------------------------------------------------------------------------------------------------------- encode
_PRIM = (type(None), bool, int, str)


def _is_shareable(o):
    return not isinstance(o, (type(None), bool, int, float, str, bytes, tuple, frozenset, Fraction, datetime.date, datetime.timedelta,
                              np.generic, type, types.FunctionType, types.MethodType, types.BuiltinFunctionType))


def encode(obj):
    """-> a JSON-serialisable structure that `decode` turns back into an equal object graph."""
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 20000))
    count = {}
    stack = []

    def walk(o):                                  # first pass: which shareable objects are reached more than once
        if not _is_shareable(o):
            if isinstance(o, tuple):
                for x in o:
                    walk(x)
            elif isinstance(o, frozenset):
                for x in o:
                    walk(x)
            return
        i = id(o)
        count[i] = count.get(i, 0) + 1
        if count[i] > 1:
            return
        if isinstance(o, dict):
            for k, v in o.items():
                walk(k)
                walk(v)
            if type(o) is defaultdict:
                walk(o.default_factory)
        elif isinstance(o, (list, set, deque)):
            for x in o:
                walk(x)
        elif isinstance(o, random.Random):
            walk(o.getstate())
        elif isinstance(o, np.ndarray):
            return
        elif _is_dfl(o):
            for v in _attrs(o).values():
                walk(v)

    walk(obj)
    ids, next_id, done = {}, [0], {}

    def sort_key(x):
        if isinstance(x, (int, str, float, bool, type(None))):
            return (0, type(x).__name__, repr(x))
        return (1, deep_digest(x), "")

    def enc(o, path):
        t = type(o)
        if o is None or t is bool or t is int or t is str:
            return o
        if t is float:
            if o != o or o in (float("inf"), float("-inf")):
                return {"$f": repr(o)}
            return o
        if t is bytes:
            return {"$b": base64.b64encode(o).decode("ascii")}
        if t is Fraction:
            return {"$q": [o.numerator, o.denominator]}
        if isinstance(o, np.generic):
            return {"$ng": [str(o.dtype), repr(o.item())]}
        if t is tuple:
            return {"$t": [enc(x, path) for x in o]}
        if t is frozenset:
            return {"$fs": [enc(x, path) for x in sorted(o, key=sort_key)]}
        if t is datetime.date or t is datetime.datetime or t is datetime.timedelta:
            return {"$dt": [t.__name__, o.isoformat() if t is not datetime.timedelta else [o.days, o.seconds, o.microseconds]]}
        if o in (list, dict, set, int, float, str, tuple) and isinstance(o, type):
            return {"$ty": o.__name__}
        if isinstance(o, (type, types.FunctionType, types.MethodType, types.BuiltinFunctionType)):
            raise NeutralError(f"cannot write {o!r}")
        i = id(o)
        if count.get(i, 0) > 1:
            if i in ids:
                return {"$ref": ids[i]}
            ids[i] = next_id[0]
            next_id[0] += 1
        tag = {"id": ids[i]} if i in ids else {}
        if t is list:
            body = {"$l": [enc(x, path) for x in o]}
        elif isinstance(o, random.Random):
            body = {"$r": enc(o.getstate(), path)}
        elif isinstance(o, np.ndarray):
            body = {"$nd": {"dtype": str(o.dtype), "shape": list(o.shape), "b": base64.b64encode(np.ascontiguousarray(o).tobytes()).decode("ascii")}}
        elif t is set:
            body = {"$s": [enc(x, path) for x in sorted(o, key=sort_key)]}
        elif t is deque:
            body = {"$dq": [enc(x, path) for x in o], "maxlen": o.maxlen}
        elif t in (dict, OrderedDict, defaultdict):
            body = {"$d": [[enc(k, path), enc(v, path)] for k, v in o.items()]}
            if t is not dict:
                body["cls"] = t.__name__
                if t is defaultdict:
                    body["factory"] = enc(o.default_factory, path)
        elif _is_dfl(o):
            cname = f"{t.__module__}.{t.__qualname__}"
            if "<locals>" in cname:
                raise NeutralError(f"cannot write local class {cname}")
            pairs = []
            for k, v in _attrs(o).items():
                try:
                    pairs.append([k, None if k in IGNORE else enc(v, path)])
                except NeutralError as e:
                    raise NeutralError(f"{cname}.{k}: {e}") from None
            body = {"$o": cname, "s": pairs}
        else:
            raise NeutralError(f"cannot write a {t.__module__}.{t.__qualname__}")
        body.update(tag)
        return body

    return enc(obj, "$")


def _is_dfl(o):
    return type(o).__module__.startswith("dfl.")


# ---------------------------------------------------------------------------------------------------------------- decode
def _cls(name):
    name = RENAMES.get(name, name)
    if not name.startswith("dfl."):
        raise NeutralError(f"a state document may only name dfl classes, not {name}")
    parts = name.split(".")
    for k in range(len(parts) - 1, 0, -1):
        try:
            mod = importlib.import_module(".".join(parts[:k]))
        except ImportError:
            continue
        obj = mod
        for p in parts[k:]:
            obj = getattr(obj, p)
        return obj
    raise NeutralError(f"class {name} does not exist in this version of the code")


def decode(doc, synthesized=None):
    """Rebuild the object graph. Raises NeutralError on anything it does not recognise. If `synthesized` is a set, the names of attributes
    that an ADAPTER supplied because the document did not carry them are added to it (so an importer can check the rest of the state
    against the exporter's digest, which could not have included them)."""
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 20000))
    memo = {}

    def reg(d, obj):
        if "id" in d:
            memo[d["id"]] = obj
        return obj

    def dec(d):
        if d is None or isinstance(d, (bool, int, float, str)):
            return d
        if isinstance(d, list):
            raise NeutralError("a bare list in a state document")
        if "$ref" in d:
            return memo[d["$ref"]]
        if "$f" in d:
            return float(d["$f"])
        if "$ty" in d:
            return {"list": list, "dict": dict, "set": set, "int": int, "float": float, "str": str, "tuple": tuple}[d["$ty"]]
        if "$b" in d:
            return base64.b64decode(d["$b"])
        if "$q" in d:
            return Fraction(*d["$q"])
        if "$ng" in d:
            dt, rep = d["$ng"]
            return np.dtype(dt).type(eval_literal(rep))
        if "$t" in d:
            return tuple(dec(x) for x in d["$t"])
        if "$fs" in d:
            return frozenset(dec(x) for x in d["$fs"])
        if "$dt" in d:
            kind, val = d["$dt"]
            if kind == "timedelta":
                return datetime.timedelta(days=val[0], seconds=val[1], microseconds=val[2])
            return getattr(datetime, kind).fromisoformat(val)
        if "$l" in d:
            out = reg(d, [])
            out.extend(dec(x) for x in d["$l"])
            return out
        if "$s" in d:
            out = reg(d, set())
            for x in d["$s"]:
                out.add(dec(x))
            return out
        if "$dq" in d:
            out = reg(d, deque(maxlen=d.get("maxlen")))
            out.extend(dec(x) for x in d["$dq"])
            return out
        if "$d" in d:
            cls = {"OrderedDict": OrderedDict, "defaultdict": defaultdict}.get(d.get("cls"), dict)
            out = reg(d, cls() if cls is not defaultdict else defaultdict(None))
            if cls is defaultdict:
                out.default_factory = dec(d["factory"])
            for k, v in d["$d"]:
                out[dec(k)] = dec(v)
            return out
        if "$r" in d:
            out = reg(d, random.Random())
            out.setstate(dec(d["$r"]))
            return out
        if "$nd" in d:
            n = d["$nd"]
            arr = np.frombuffer(base64.b64decode(n["b"]), dtype=np.dtype(n["dtype"])).reshape(n["shape"]).copy()
            return reg(d, arr)
        if "$o" in d:
            cls = _cls(d["$o"])
            out = reg(d, cls.__new__(cls))
            attrs = {}
            for k, v in d["s"]:
                attrs[k] = dec(v)
            fill = ADAPTERS.get(RENAMES.get(d["$o"], d["$o"]))
            if fill:
                before = set(attrs)
                fill(out, attrs)
                if synthesized is not None:
                    synthesized.update(set(attrs) - before)
            for k, v in attrs.items():
                object.__setattr__(out, k, v)
            return out
        raise NeutralError(f"unrecognised element {list(d)[:3]}")

    return dec(doc)


def eval_literal(rep):
    import ast
    return ast.literal_eval(rep)


# ---------------------------------------------------------------------------------------------------------------- documents
def dumps_doc(obj, manifest):
    """-> gzip bytes of a state document: {format, version, manifest, state}, with canonical (sorted-key, compact) JSON outside the
    order-preserving pair lists inside `state`."""
    doc = {"format": DOC_FORMAT, "version": DOC_VERSION, "manifest": manifest, "state": encode(obj)}
    text = json.dumps(doc, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return gzip.compress(text.encode("utf-8"), 6, mtime=0)


def loads_doc(raw):
    try:
        doc = json.loads(gzip.decompress(raw).decode("utf-8"))
    except Exception as e:
        raise NeutralError(f"not a state document: {e}")
    if doc.get("format") != DOC_FORMAT:
        raise NeutralError("not a dfl state document")
    if doc.get("version") != DOC_VERSION:
        raise NeutralError(f"state document version {doc.get('version')} is not supported (this code reads version {DOC_VERSION}; version 1 "
                           "carried digests of an older algorithm that could not see every part of the state). Re-export the league "
                           "with this code's exporter: persist.upgrade does that")
    return doc


def state_digest(raw):
    """SHA-256 of the *uncompressed* document text: stable across gzip implementations."""
    return hashlib.sha256(gzip.decompress(raw)).hexdigest()


def batch_chain(prev, items):
    """Hash chain over archive batches [(event seq, record count, records digest)] in event order, starting from `prev`."""
    for seq, n, digest in items:
        prev = hashlib.sha256(f"{prev}|{seq}|{n}|{digest}".encode()).hexdigest()
    return prev


def _archive_chain_of(r):
    """The chain over every archive batch this league has committed (the file's base, then its journal), or None without an archive."""
    if not r.meta.get("archive"):
        return None
    base = r.meta.get("archive_base") or {"chain": "0" * 64}
    rows = r.db.execute("SELECT seq, n_records, records_digest FROM journal WHERE seq <= ? AND n_records > 0 ORDER BY seq", (r.seq,)).fetchall()
    return batch_chain(base["chain"], rows)


def runner_manifest(r):
    """What a state document says about the league it came from. `r` is any object with `.u` (the Universe), `.meta`, `.seq`, `.chain`,
    which is what persist.Runner has in every version of the league file."""
    try:
        rule = importlib.import_module("dfl.engine.params").RULE_VERSION
    except Exception:
        rule = None
    m = r.meta
    return {"league_format": m.get("format"), "fingerprint": m.get("fingerprint"), "seq": r.seq, "chain": r.chain, "seed": m.get("seed"),
            "snapshot_every": m.get("snapshot_every"), "keep": m.get("keep"), "universe_args": m.get("universe_args"),
            "tables": m.get("tables"), "lineage": m.get("lineage", []), "created_with": m.get("created_with"), "rule_version": rule,
            "archive": m.get("archive"), "league_id": m.get("league_id"), "archive_chain": _archive_chain_of(r),
            "digest_algorithm": DIGEST_VERSION, "deep_digest": deep_digest(r.u), "digest_parts": digest_parts(r.u), "rng_states": rng_states(r.u)}
